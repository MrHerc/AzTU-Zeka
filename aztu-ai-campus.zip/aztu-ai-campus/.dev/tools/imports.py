"""Check that every `import { a, b } from "./x.js"` names an export of x.js. Usage: python .dev/tools/imports.py"""
import re
import sys
from pathlib import Path

JS = Path(__file__).resolve().parents[2] / "static" / "js"
exp_rx = re.compile(r"^export\s+(?:async\s+)?(?:const|let|var|function\*?|class)\s+([A-Za-z_$][\w$]*)", re.M)
exp_list_rx = re.compile(r"^export\s*\{([^}]*)\}", re.M)
imp_rx = re.compile(r"import\s*\{([^}]*)\}\s*from\s*[\"']\./([\w.-]+)[\"']", re.S)


def exports(path: Path) -> set:
    s = path.read_text(encoding="utf-8")
    names = set(exp_rx.findall(s))
    for grp in exp_list_rx.findall(s):
        for part in grp.split(","):
            part = part.strip()
            if part:
                names.add(part.split(" as ")[-1].strip())
    return names


bad = 0
cache = {}
for f in sorted(JS.glob("*.js")):
    s = f.read_text(encoding="utf-8")
    for grp, mod in imp_rx.findall(s):
        target = JS / mod
        if not target.exists():
            print(f"FAIL {f.name}: module {mod} not found")
            bad += 1
            continue
        ex = cache.setdefault(mod, exports(target))
        for part in grp.split(","):
            name = part.strip().split(" as ")[0].strip()
            if name and name not in ex:
                print(f"FAIL {f.name}: '{name}' is not exported by {mod}")
                bad += 1
print("IMPORTS:", "ALL OK" if not bad else f"{bad} PROBLEM(S)")
sys.exit(1 if bad else 0)
