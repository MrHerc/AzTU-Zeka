"""Screenshot a route inside a 390x844 iframe (real phone width). Usage: python .dev/tools/m390.py --role student --route /student [--lang az] --out file.png
Writes a temporary harness page to static/dev/ (removed afterwards)."""
import argparse
import shutil
import subprocess
import tempfile
import urllib.parse
from pathlib import Path

EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
ROOT = Path(__file__).resolve().parents[2]
ap = argparse.ArgumentParser()
ap.add_argument("--role", default="student")
ap.add_argument("--route", default="/student")
ap.add_argument("--lang", default="az")
ap.add_argument("--out", required=True)
ap.add_argument("--budget", type=int, default=12000)
a = ap.parse_args()
nxt = f"/?lang={a.lang}&audit=1#{a.route}"
src = f"/demo/login?role={a.role}&next={urllib.parse.quote(nxt, safe='')}"
dev = ROOT / "static" / "dev"
dev.mkdir(exist_ok=True)
harness = dev / "m390.html"
harness.write_text(f"""<!doctype html><html><head><meta charset="utf-8"><title>390</title>
<style>body{{margin:0;background:#cfd6e4;display:grid;place-items:center;height:100vh}}iframe{{width:390px;height:844px;border:0;border-radius:22px;background:#fff;box-shadow:0 10px 40px rgba(0,0,0,.25)}}</style>
</head><body><iframe src="{src}" title="mobile"></iframe></body></html>""", encoding="utf-8")
prof = tempfile.mkdtemp(prefix="zeka-m390-")
try:
    subprocess.run([EDGE, "--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars", f"--user-data-dir={prof}", "--window-size=470,900",
                    f"--virtual-time-budget={a.budget}", f"--screenshot={a.out}", "http://127.0.0.1:5070/static/dev/m390.html"], capture_output=True, timeout=90)
finally:
    shutil.rmtree(prof, ignore_errors=True)
    harness.unlink(missing_ok=True)
    try:
        dev.rmdir()
    except OSError:
        pass
print(a.out, Path(a.out).stat().st_size if Path(a.out).exists() else "MISSING")
