"""Render SPA routes in headless Edge and scan the resulting DOM.

Usage:
  python .dev/tools/dom.py --role student --lang en --routes /student,/student/schedule [--mobile] [--debug-i18n] [--out DIR]
  python .dev/tools/dom.py --all [--lang az,en,ru]          # every known route for every role
Findings: JS errors (#__errors), error toasts, 'undefined'/'NaN'/'[object Object]', missing translations (⟦…⟧ with
--debug-i18n) and, for en/ru, Azerbaijani-only letters in visible UI text (course content and names excluded heuristically).
Read-only: it only performs GET navigations through the demo login (which creates a session row)."""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import html as htmllib
import os
import re
import shutil
import subprocess
import tempfile
import urllib.parse
from pathlib import Path

EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
BASE = "http://127.0.0.1:5070"
ROUTES = {
    "student": ["/student", "/student/schedule", "/student/courses", "/student/course/1", "/student/tutor/1", "/student/campus",
                "/student/quizzes", "/student/attendance", "/student/grades", "/student/services", "/student/apply/enrollment_certificate",
                "/student/apply/absence_excuse", "/student/requests", "/student/requests/34", "/news", "/news/1", "/achievements", "/contact",
                "/guide", "/guide?tab=guides", "/guide?tab=faq", "/support", "/support?tab=mine", "/support/1", "/profile", "/notifications"],
    "teacher": ["/teacher", "/teacher/schedule", "/teacher/courses", "/teacher/course/1", "/teacher/course/1?tab=test", "/teacher/studio",
                "/teacher/questions", "/teacher/academy", "/teacher/academy/track/ai", "/teacher/academy/module/1", "/teacher/tools",
                "/teacher/syllabus", "/news", "/achievements", "/support", "/guide"],
    "office": ["/office", "/office/request/3", "/office/registry", "/staff/support", "/staff/support/1", "/staff/news", "/news",
               "/staff/feedback", "/contact", "/guide"],
    "leader": ["/leader", "/staff/feedback", "/office", "/office/registry", "/admin/audit", "/achievements", "/guide"],
    "admin": ["/admin", "/admin/audit", "/staff/support", "/staff/feedback", "/staff/news", "/guide"],
}
AZ_ONLY = re.compile(r"[əƏğĞıİ]")
NAME_RX = re.compile(r"(Dos\.|Prof\.|Assoc\. Prof\.|доц\.|проф\.)?\s*[A-ZƏÖÜŞÇĞİ][a-zəıöüşçğ]+ [A-ZƏÖÜŞÇĞİ][a-zəıöüşçğ]+(\s*·.*)?")


def url_for(role, route, lang, debug):
    qs = f"lang={lang}&audit=1" + ("&i18n=debug" if debug else "")
    nxt = f"/?{qs}#{route}"
    return f"{BASE}/demo/login?role={role}&next={urllib.parse.quote(nxt, safe='')}"


def dump(role, route, lang, out: Path, mobile=False, debug=False, budget=9000):
    prof = tempfile.mkdtemp(prefix="zeka-edge-")
    size = "390,844" if mobile else "1366,900"
    args = [EDGE, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-extensions",
            f"--user-data-dir={prof}", f"--window-size={size}", f"--virtual-time-budget={budget}", "--dump-dom", url_for(role, route, lang, debug)]
    try:
        r = subprocess.run(args, capture_output=True, timeout=90)
        dom = r.stdout.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        dom = ""
    finally:
        shutil.rmtree(prof, ignore_errors=True)
    slug = re.sub(r"[^a-z0-9]+", "-", route.lower()).strip("-") or "root"
    f = out / f"{role}-{lang}{'-m' if mobile else ''}-{slug}.html"
    f.write_text(dom, encoding="utf-8")
    return f


def visible_text(dom: str) -> str:
    s = re.sub(r"(?is)<(script|style|svg|template)[^>]*>.*?</\1>", " ", dom)
    s = re.sub(r"(?is)<(textarea|code|pre)[^>]*>.*?</\1>", " ", s)
    s = re.sub(r"(?s)<[^>]+>", "\n", s)
    return htmllib.unescape(s)


IGNORE_AZ = re.compile(r"Məmmədova|Əliyev|Rzayeva|Həsənova|Quliyev|Kazımova|İT-25|İT-|Səfərli|Vəliyev|Cavid|Bakı|AzTU|Zəka|Azərbaycanca|"
                       r"Elçin|Səbinə|Günel|Leyla|Nigar|Rauf|Aysel|Tural|Gülnar|Ülviyyə|Rəqəmsal|Əsas korpus|İNG|RİY|FİZ|QRF|KOMP|ELM", re.I)


def scan(f: Path, lang: str, debug: bool):
    dom = f.read_text(encoding="utf-8")
    issues = []
    if len(dom) < 800:
        issues.append("EMPTY DOM (server down or page crashed?)")
        return issues
    m = re.search(r'id="__errors"[^>]*>([^<]*)<', dom)
    if m and m.group(1).strip():
        issues.append("JS ERROR: " + m.group(1).strip()[:300])
    for t in re.findall(r'class="toast err"[^>]*>(.*?)</div>', dom, re.S)[:3]:
        issues.append("ERROR TOAST: " + re.sub(r"<[^>]+>", "", t).strip()[:200])
    txt = visible_text(dom)
    for bad in ("undefined", "NaN", "[object Object]", "null null"):
        for line in txt.splitlines():
            if re.search(rf"(^|\W){re.escape(bad)}(\W|$)", line):
                issues.append(f"RAW '{bad}': {line.strip()[:160]}")
                break
    if 'class="skel-wrap"' in dom and 'id="page"' in dom and re.search(r'<main[^>]*id="page"[^>]*>\s*<div class="skel-wrap"', dom):
        issues.append("STUCK SKELETON (page never finished loading)")
    if debug:
        miss = sorted(set(re.findall(r"⟦([^⟧]{1,120})⟧", txt)))
        if miss:
            issues.append(f"MISSING i18n ({len(miss)}): " + " | ".join(miss[:12]))
    if lang != "az":
        az = []
        for line in txt.splitlines():
            line = line.strip()
            if not line or not AZ_ONLY.search(line) or IGNORE_AZ.search(line):
                continue
            if re.fullmatch(r"[A-ZƏÖÜŞÇĞİ]{2}", line) or NAME_RX.fullmatch(line):
                continue
            az.append(line[:120])
        if az:
            issues.append(f"AZ TEXT IN {lang.upper()} ({len(az)}): " + " | ".join(sorted(set(az))[:10]))
    return issues


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--role", default="student")
    ap.add_argument("--routes", default="")
    ap.add_argument("--lang", default="az")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--mobile", action="store_true")
    ap.add_argument("--debug-i18n", action="store_true")
    ap.add_argument("--out", default=str(Path(os.environ.get("TEMP", ".")) / "zeka-dom"))
    ap.add_argument("--workers", type=int, default=4)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    jobs = []
    langs = a.lang.split(",")
    if a.all:
        for role, rs in ROUTES.items():
            for lg in langs:
                jobs += [(role, r, lg) for r in rs]
    else:
        for lg in langs:
            jobs += [(a.role, r, lg) for r in (a.routes.split(",") if a.routes else ROUTES[a.role])]
    total = 0
    with cf.ThreadPoolExecutor(a.workers) as ex:
        futs = {ex.submit(dump, role, r, lg, out, a.mobile, a.debug_i18n): (role, r, lg) for role, r, lg in jobs}
        for fu in cf.as_completed(futs):
            role, r, lg = futs[fu]
            f = fu.result()
            if 'id="app"' not in f.read_text(encoding="utf-8") and "login-card" not in f.read_text(encoding="utf-8"):
                f = dump(role, r, lg, out, a.mobile, a.debug_i18n, budget=20000)  # slow first load under parallel load: retry once
            issues = scan(f, lg, a.debug_i18n)
            if 'id="app"' not in f.read_text(encoding="utf-8"):
                issues.insert(0, "APP SHELL NOT RENDERED (stuck on boot splash)")
            total += len(issues)
            print(f"{'OK  ' if not issues else 'ISSUE'} {role:8} {lg} {r}")
            for i in issues:
                print("      - " + i)
    print(f"DOM SCAN: {len(jobs)} pages, {total} issue(s). Dumps in {out}")


if __name__ == "__main__":
    main()
