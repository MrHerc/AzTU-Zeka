"""Print random AZ / EN / RU samples of a chunk. Usage: python .dev/tools/i18n_sample.py <chunk> [n]"""
import json
import random
import sys
from pathlib import Path

I18N = Path(__file__).resolve().parents[2] / "i18n"
ch, n = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 8
src = json.loads((I18N / "todo" / f"{ch}.json").read_text(encoding="utf-8"))
en = json.loads((I18N / "en" / f"{ch}.json").read_text(encoding="utf-8"))
ru = json.loads((I18N / "ru" / f"{ch}.json").read_text(encoding="utf-8"))
random.seed(len(src))
for k in random.sample(list(src), min(n, len(src))):
    print("AZ:", k[:150])
    print("EN:", str(en.get(k))[:150])
    print("RU:", str(ru.get(k))[:150])
    print()
plur = [k for k in src if isinstance(ru.get(k), dict)]
print(f"plural entries: {len(plur)}", plur[:3], [ru[k] for k in plur[:2]])
