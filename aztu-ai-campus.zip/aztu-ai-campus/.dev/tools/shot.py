"""Screenshot one SPA route with headless Edge.
Usage: python .dev/tools/shot.py --role student --route /achievements [--lang en] [--mobile] [--out file.png] [--budget 9000]"""
import argparse
import os
import shutil
import subprocess
import tempfile
import urllib.parse
from pathlib import Path

EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
ap = argparse.ArgumentParser()
ap.add_argument("--role", default="student")
ap.add_argument("--route", default="/student")
ap.add_argument("--lang", default="az")
ap.add_argument("--mobile", action="store_true")
ap.add_argument("--extra", default="audit=1", help="extra query params for the SPA, e.g. 'audit=1' (default) or ''")
ap.add_argument("--budget", type=int, default=9000)
ap.add_argument("--out", default="")
a = ap.parse_args()
qs = "&".join(x for x in (f"lang={a.lang}", a.extra) if x)
url = f"http://127.0.0.1:5070/demo/login?role={a.role}&next={urllib.parse.quote(f'/?{qs}#{a.route}', safe='')}"
out = Path(a.out or Path(os.environ.get("TEMP", ".")) / f"zeka-{a.role}-{a.lang}{'-m' if a.mobile else ''}.png")
prof = tempfile.mkdtemp(prefix="zeka-shot-")
try:
    subprocess.run([EDGE, "--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars", f"--user-data-dir={prof}",
                    f"--window-size={'390,844' if a.mobile else '1440,900'}", f"--virtual-time-budget={a.budget}", f"--screenshot={out}", url],
                   capture_output=True, timeout=90)
finally:
    shutil.rmtree(prof, ignore_errors=True)
print(out, out.stat().st_size if out.exists() else "MISSING")
