"""Validate i18n/<lang>/<chunk>.json against i18n/todo/<chunk>.json. Usage: python .dev/tools/i18n_check.py [chunk ...]"""
import json
import re
import sys
from pathlib import Path

I18N = Path(__file__).resolve().parents[2] / "i18n"
PH = re.compile(r"\{(\w+)\}")
chunks = sys.argv[1:] or sorted(p.stem for p in (I18N / "todo").glob("*.json"))
total_bad = 0
for ch in chunks:
    src = json.loads((I18N / "todo" / f"{ch}.json").read_text(encoding="utf-8"))
    for lg in ("en", "ru"):
        f = I18N / lg / f"{ch}.json"
        if not f.exists():
            print(f"{ch:11} {lg}: MISSING")
            continue
        try:
            tr = json.loads(f.read_text(encoding="utf-8"))
        except ValueError as ex:
            print(f"{ch:11} {lg}: INVALID JSON {ex}")
            total_bad += 1
            continue
        missing = [k for k in src if k not in tr or tr[k] in ("", None)]
        extra = [k for k in tr if k not in src]
        probs = []
        for k, v in tr.items():
            if k not in src:
                continue
            want = sorted(set(PH.findall(k)))
            forms = v.values() if isinstance(v, dict) else [v]
            if isinstance(v, dict):
                need = {"one", "other"} if lg == "en" else {"one", "few", "many"}
                if not need <= set(v):
                    probs.append(f"plural keys {sorted(v)}: {k[:50]!r}")
            for x in forms:
                if not isinstance(x, str):
                    probs.append(f"non-string: {k[:50]!r}")
                    continue
                if sorted(set(PH.findall(x))) != want:
                    probs.append(f"placeholders {sorted(set(PH.findall(x)))} != {want}: {k[:50]!r}")
                if k.count("**") != x.count("**"):
                    probs.append(f"** markers differ: {k[:50]!r}")
            same = isinstance(v, str) and v == k and re.search(r"[əğıöüşçƏĞİÖÜŞÇ]", k)
            if same:
                probs.append(f"untranslated (identical AZ): {k[:50]!r}")
        bad = len(missing) + len(probs)
        total_bad += bad
        print(f"{ch:11} {lg}: {len(tr) - len(extra)}/{len(src)} keys, missing {len(missing)}, extra {len(extra)}, problems {len(probs)}")
        for p in (probs + [f"missing: {m[:60]!r}" for m in missing])[:8]:
            print("     -", p)
print("I18N CHECK:", "OK" if not total_bad else f"{total_bad} issue(s)")
