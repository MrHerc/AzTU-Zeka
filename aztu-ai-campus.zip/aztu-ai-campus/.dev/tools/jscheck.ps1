# Parse-check every SPA module (no bundling). Usage: powershell -File .dev\tools\jscheck.ps1 [file ...]
param([string[]]$Files)
$bun = 'C:\Users\ssafarli\AppData\Local\Kiro-Cli\bun.exe'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$out = Join-Path $env:TEMP 'zeka-jscheck'
New-Item -ItemType Directory -Force $out | Out-Null
if (-not $Files) { $Files = Get-ChildItem (Join-Path $root 'static\js') -Filter *.js | ForEach-Object { $_.FullName } }
$bad = 0
foreach ($f in $Files) {
  $res = & $bun build --no-bundle --target=browser --outdir $out $f 2>&1 | Out-String
  if ($LASTEXITCODE -ne 0) { $bad++; Write-Output ('FAIL ' + (Split-Path -Leaf $f)); Write-Output $res }
  else { Write-Output ('ok   ' + (Split-Path -Leaf $f)) }
}
Write-Output ('JSCHECK: ' + $(if ($bad) { "$bad FAILED" } else { 'ALL OK' }))
