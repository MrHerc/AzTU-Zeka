"""List every registerTour() call: key, route, go, roles and number of steps. Usage: python .dev/tools/tours.py"""
import re
from pathlib import Path

JS = Path(__file__).resolve().parents[2] / "static" / "js"
for f in sorted(JS.glob("*.js")):
    s = f.read_text(encoding="utf-8")
    for m in re.finditer(r'registerTour\("([^"]+)",\s*\{', s):
        if f.name == "core.js":
            continue
        start = m.end()
        depth, i = 1, start
        while i < len(s) and depth:
            depth += {"{": 1, "}": -1}.get(s[i], 0)
            i += 1
        body = s[start:i]
        route = re.search(r'route:\s*"([^"]+)"', body)
        go = re.search(r'go:\s*"([^"]+)"', body)
        roles = re.search(r"roles:\s*\[([^\]]*)\]", body)
        steps = len(re.findall(r"\bsel:", body))
        print(f"{f.name:16} {m.group(1):22} route={route.group(1) if route else '?':28} go={go.group(1) if go else '-':30} "
              f"roles={(roles.group(1).replace(chr(34), '') if roles else 'all'):24} steps={steps}")
