# Zəka v0.3 — working contract for parallel workstreams

Project: `C:\Users\ssafarli\projects\aztu-ai-campus` (stdlib Python server + vanilla-JS SPA, demo for Azerbaijan Technical University).
Demo server (shared, already running): http://127.0.0.1:5070. Static JS/CSS is re-read on every request, so front-end edits are live
on reload. **Never** restart/stop the shared server on 5070, never run `tests\selftest.py`, never delete `data\`.

## 1. What v0.3 is
A fully professional, trilingual (Azerbaijani / English / Russian) portal with page-by-page interactive guides, smooth motion,
mobile-first layouts, support & feedback, real AzTU achievements and contacts. The infrastructure is done (see §3). Your job is to bring
your module(s) up to that standard: **professional Azerbaijani copy**, **every visible string translatable**, **no empty/dead parts**,
**mobile friendly**, **page guides**.

## 2. Copy rules (Azerbaijani is the source language)
- Natural, idiomatic, professional Azerbaijani — not a literal translation. Short. Remove filler and duplicated explanations.
- Secondary details go behind an ⓘ: `infoTip(t("…"))`, or `pageHead(..., { info: t("…") })`. Page subtitles: one short line.
- Register: formal. Sentences/instructions use the "siz" form: "Faylı seçin", "Sənədi yükləyin".
  **Buttons and menu actions use the short imperative**: "Göndər", "Yadda saxla", "Ləğv et", "Bağla", "Yüklə", "Çap et", "Başla",
  "Davam et", "Bax", "Redaktə et", "Sil", "Təsdiqlə", "Rədd et". Tabs/headings are nouns: "Sorğularım", "Davamiyyət".
- No emojis in UI text (emoji only where they are the UI, e.g. the feedback scale). No exclamation marks unless truly needed.
- Placeholders: "Məsələn: …" or a short hint. Empty states: what is missing + what to do next (with an action button).
- Terminology (use exactly these):
  course=**fənn**, courses=**fənlər**, quiz/test=**test** (NOT "quiz"), Quiz Studio=**Test studiyası**, e-services=**e-xidmətlər**,
  request/application=**müraciət**, support ticket=**dəstək sorğusu**, certificate (enrolment)=**arayış**, document=**sənəd**,
  attendance=**davamiyyət**, absence=**qayıb**, excused=**üzrlü**, grades=**qiymətlər**, assessment=**qiymətləndirmə**,
  schedule=**dərs cədvəli**, dean's office=**dekanlıq**, leadership=**rəhbərlik**, notification=**bildiriş**, achievements=**nailiyyətlər**,
  feedback=**rəy**, guide=**bələdçi**, page guide=**səhifə bələdçisi**, AI tutor=**AI tutor**, campus assistant=**kampus köməkçisi**,
  material=**material**, syllabus=**sillabus**, teacher academy=**AI Akademiya**, tools=**texnoloji həllər**, registry=**sənəd reyestri**,
  deadline/SLA=**icra müddəti**, draft=**qaralama**, approve=**təsdiqlə**, publish=**dərc et**.

## 3. Front-end API you must use (static/js/core.js unless noted)
- `t("Azərbaycan mətni {x}", { x })` — every user-visible string (text nodes, title/aria-label/placeholder/alt, toasts, modal titles,
  button labels, chart labels, empty states, errors you compose). The **literal Azerbaijani text is the key**: pass a string literal,
  never a variable, never build sentences by concatenating translated fragments (word order differs in EN/RU). Counts: put `{n}` in
  the text and pass `{ n }` (plural forms are handled by the catalog). Keep markup out of t(); if you need emphasis, split into
  separate t() calls per element or use `md(t("**…**"))`.
- Data coming from the server (course names, service names, statuses, notifications, news…) is **already localized** by the server
  (X-Lang header is sent automatically). Do not wrap server data in t(). Never compare human-readable server labels in code — use codes.
- Course *content* (lecture materials, quiz questions, tutor quotes) stays in the language of instruction (Azerbaijani). Where an
  EN/RU user would be surprised, add `infoTip(t("Fənn materialları tədris dilində təqdim olunur."))`.
- Dates/numbers: `fmtDate`, `fmtDateTime`, `fmtTime`, `fmtDayLong`, `fmtDayMonth`, `fmtMonthYear`, `ago`, `MONTHS`, `WEEKDAYS`
  (all localized), `num(n, dec)`. Never hard-code Azerbaijani month/day names.
- `STATUS`, `statusLabel(s)`, `badge(status, label?)`, `MODE_LABEL`, `QTYPE` — already translated.
- `pageHead(title, sub, actions, crumbs, { info })` — adds the "Səhifə bələdçisi" button automatically when a tour is registered.
- States: `loading()` (skeleton), `skelLines(n)`, `spinner()`, `empty(icon, title, text, { label, go | id, icon, cls })`,
  `failed(message)` (error with retry button; main.js re-renders on click), `confirmBox(title, text, okLabel, danger)` → Promise<bool>.
- `infoTip(text)` — ⓘ popover (hover/focus/tap). `copyText(text)`.
- Numbers that should count up: `cnt(value, { dec, prefix, suffix })`. Charts (`lineChart`, `barChart`, `ring`, `sparkline`,
  `progress`) animate automatically. Cards below the fold reveal on scroll automatically. `.tabs > .tab.active` gets a sliding ink.
- Documents and files open **inside the portal** (no pop-ups, works without a browser PDF plug-in):
  `openDoc(id, title)`, `openSyllabus(courseId, title)`, `openFile(fileId, filename)`, `downloadFile(fileId, filename)`,
  `openInNewTab(kind, id)` (`kind` = doc | syl | file). Never call `window.open` for app documents.
- Page guides: `registerTour(key, { route, roles, title, group, icon, go, steps: [{ sel, title, text }] })`
  - `route` = the SPA route pattern (e.g. "/student/course/:id"); `go` = a concrete path for the guide hub when the route has
    params (e.g. "/student/course/1"); `roles` = roles that see it; `group` = section name for the hub (use the sidebar section, t()).
  - 3–6 steps, each pointing at a **stable** selector that exists after render (add `id` or `data-tour="…"` attributes);
    titles 1–4 words, texts ≤ 2 short sentences, all in t(). Steps whose element is missing are skipped automatically.
  - Every page in your module gets a guide (detail pages too).
- `HOME`, `ROLES`, `NAV` come from shell.js. `S.user`, `S.app` as before. `LANG` (az|en|ru) if you really need it.
- Layout/mobile: use the existing grid classes (`grid g-2 g-3 g-4 g-12 g-21 g-auto`, `row wrap`, `stack`, `form-grid`) — they collapse
  on small screens. Wrap every `<table>` in `<div class="table-wrap">`. No fixed pixel widths on containers; long button groups use
  `row wrap`. The app has a bottom navigation bar under 720 px and a floating feedback button — leave room (the page already has padding).
  Check your pages at 390 px width.
- Module CSS: only in your own file `static/css/m-<module>.css` (already linked). Do not edit `app.css`.

## 4. "No empty parts" checklist (audit every page you own)
- Every list/table has an empty state with a next step; every request has loading and error states (`failed`).
- Every clickable thing does something meaningful (open detail, filter, navigate). No dead buttons, no "coming soon" without context.
- Lists of items that have details (courses, requests, quizzes, materials, news, modules…) open a detail view or modal.
- Files/documents/attachments/syllabi/certificates use the in-app viewer functions above.
- Forms validate with clear messages; success leads somewhere (toast + next step).
- Demo-only features are labelled clearly but politely ("Pilot mərhələsində aktiv olacaq"), never left blank.

## 5. Verification (run before you report)
- `powershell -NoProfile -ExecutionPolicy Bypass -File .dev\tools\jscheck.ps1 static\js\<file>.js` → must be ok.
- `python .dev\tools\imports.py` → ALL OK (a missing export breaks the whole SPA).
- `python tools\i18n.py lint static\js\<file>.js` → aim for 0 findings (brand names / codes are fine; explain any you keep).
- `python .dev\tools\dom.py --role <role> --lang az --routes <your routes> --out %TEMP%\zeka-dom-<module>` → 0 issues, and open the dumps
  to confirm real content rendered. Also run with `--mobile`.
- Optional visual check: `python .dev\tools\shot.py --role <role> --route <route> [--mobile] --out <png>` then view the image.
- Don't run EN/RU checks yet — catalogs are generated after all modules are finished.

## 6. Hand-off
Report: files changed, pages covered, guides registered (keys), empty parts you filled, anything you could not finish, and any
string that the translators should know about (ambiguous terms). Do not create other markdown files.
