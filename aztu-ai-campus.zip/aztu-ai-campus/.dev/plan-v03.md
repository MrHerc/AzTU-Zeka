# v0.3 work plan (dev note, not shipped)

User request (2026-10-02 17:00): 1) interactive guide explaining every part (multi-page tours) 2) 3 languages AZ/EN/RU
3) smooth transitions + interactive animations 4) professional AZ copy (not literal), remove clutter, move extra info to (i) popovers
5) Support + Feedback + Contact 6) AzTU achievements from REAL sources linking to news.

## Decisions
- i18n = gettext style: Azerbaijani source string is the key. Client `t("AZ text", {params})` (static/js/i18n.js),
  dictionaries static/locales/{en,ru}.json (map az->tr). Server: app/i18n.py: S(text, lang), T3(text, **p) -> {az,en,ru},
  S_() extraction marker, tr3()/J3() for content stored in DB as JSON i18n text, localize() walker applied to every JSON
  response in web.py (picks req.lang from X-Lang header). Catalog app/locales/{en,ru}.json (server+content strings).
- Plurals: value may be object {one,few,many,other}; param n.
- Extraction: tools/i18n_extract.py -> i18n/source/*.json {id: az}; translators (subagents) -> i18n/{en,ru}/*.json {id: tr};
  tools/i18n_build.py -> static/locales/*.json + app/locales/*.json.
- Course materials/quizzes stay in course language (content). Tutor scaffolding phrases localized, quotes stay original.
- Achievements: content/achievements.json from official AzTU RSS feed (scratch runtime-c044e860/feed.xml) + edu.gov.az (QS 2026).
  Each achievement -> news row kind "achievement" with source_name/source_url.
- Contacts (verified from aztu.edu.az JSON-LD): H. Cavid prospekti 25, Baku AZ1073; +994 12 539 13 48; info@aztu.edu.az;
  FB/IG/LinkedIn/YouTube.
- DB SCHEMA_VERSION=3 -> auto reset old DB.

## Steering 2026-10-02 (user, added mid-turn)
S1 sidebar: "by Safarov Industries" credit (left panel, under brand / footer)
S2 full mobile responsiveness (all pages, tables, wizards, modals, tours)
S3 fill empty parts, e.g. viewing a PDF -> in-app viewer modal (docs via iframe + print; files: image/PDF preview pages
   rendered server-side as text "paper", download/open-in-tab); never rely on window.open / browser PDF plugin only
S4 collapsible left sidebar (toggle, persisted, icon-only rail on desktop)
S5 full audit: empty states with actions, dead buttons, missing detail views -> fill

## Status
- [x] server i18n core (i18n.py, web.py, common.py) + tutor.py (trilingual tutor/campus/practice) + pdftext.py (PDF preview)
- [x] engine: Cyrillic tokens, old composer removed; selftest updated (ALL PASSED)
- [x] store: schema v3 auto-reset, notify i18n dicts, support/feedback tables + support.py seed
- [x] r_support.py (tickets, feedback, system status, achievements, contact), r_core (lang prefs, badges, multilingual search, file preview)
- [x] content: achievements.json (18 real items, verified) + contacts.json (official)
- [x] client infra: i18n.js, core.js (viewer, infoTip, skeletons, motion, tours registry), shell.js (collapse, Safarov credit, lang, bottom nav,
      FAB), tour.js (engine + hints), main.js (transitions, login, profile, notifications), support.js, achievements.js, guide.js, app.css v0.3
- [x] tools: tools/i18n.py (lint/extract/build/stats), .dev/tools/{jscheck.ps1, imports.py, dom.py, shot.py}; .dev/CONTRACT.md
- [ ] PHASE B (subagents): student.js | services.js | news.js | teacher.js | academy.js | staff.js+chat.js | backend py | content json
      wave1 died 18:37 (runtime crash) — saved work: student/news/academy/staff done, guide.json done, r_services+r_admin partly.
      wave2 (5): services c27cbd6b, teacher 47f5f378, chat c3754225 (DONE), backend 364c362a, content 876e7a66 (DONE)
- [ ] INTEGRATION (me, after wave2): rename "Quiz Studio" -> "Test studiyası" everywhere: tools.json zeka name + app/r_academy.py:~202
      exact-match, academy.json "Quiz Studio-da" tasks, teacher.js/README; seed.json grade_appeal option "Quiz" -> "Test" + store.py:~562
      demo seed + any show_if; r_learning.py "Yeni quiz" notify -> T3("Yeni test: {title}"). Done already: student tours deepened (chat anchors),
      no hub links for quiz/attempt guides, tourCatalog drops parametric routes without go.
- [x] INTEGRATION done 18:58 (Quiz→Test rename in code+content, f-string notifications -> T3, week labels i18n, news {a}{b} fix)
- [x] PHASE C done 19:20: 3473 strings EN+RU (100%), catalogs built; fixes: positional-only S/T3, codes never translated
      (role 'admin' crash in RU), composite rule (rooms/locations), FAQ/quiz 'q' translation, personas, tool metadata
- [x] PHASE D done 19:50: selftest ALL PASSED (incl. v0.3 checks); DOM scans 65 pages x AZ/EN/RU + mobile, 0 errors, 0 missing keys;
      390px harness screenshots OK; README v0.3; DB reset to fresh seed; server running on 5070
- [x] PHASE E done 20:40 (post-report audit): layout audit now also flags content wider than its card (CARD SPILL) and text
      spilling from shrunken boxes; fixed: course-page timetable rows (fixed 150px day column), long badges wrap (tool licence
      terms), tool price colours via server price_tone (were lost in EN/RU), material headings never catalog-translated
      ("Giriş" showed as "Log in"); 65 pages x AZ/EN/RU x desktop/mobile clean; selftest ALL PASSED; catalogs 100%; DB fresh
- [ ] PHASE D: selftest + new tests (support/feedback/achievements/X-Lang), restart server, DOM scan x3 langs (+debug-i18n, +mobile),
      fix, README v0.3, reset DB, final report (AZ) with preview marker + STEERING note
